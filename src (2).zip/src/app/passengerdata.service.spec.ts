import { TestBed } from '@angular/core/testing';

import { PassengerdataService } from './passengerdata.service';

describe('PassengerdataService', () => {
  let service: PassengerdataService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PassengerdataService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

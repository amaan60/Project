import { Injectable } from '@angular/core';
import { Subject, BehaviorSubject } from 'rxjs';
import { BookingDetails } from './bookingdetails';

@Injectable({
  providedIn: 'root'
})
export class PassengerdataService {

  bookingdetailsobj = new BookingDetails(123,"",23, 450, 230, 3, "", "","","","");
  private passengerDataSource = new BehaviorSubject<BookingDetails>(this.bookingdetailsobj);
  public passengerData$ = this.passengerDataSource.asObservable();


  constructor() { }

  storePassengerData(bookingdetails : BookingDetails)
  {
    this.passengerDataSource.next(bookingdetails);
  }
}

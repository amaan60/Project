export class Booking
{
    busId : number;
    passengerNames: [];
    seatsBooked : number; 
    totalFare : string;
    bookingId : number;
    seatNo : string;
    bookingDate : string;

    constructor(busId, passengerNames, seatsBooked, totalFare, bookingId, seatNo,bookingDate)
    {
        this.busId = busId;
        this.passengerNames = passengerNames;
        this.seatsBooked = seatsBooked;
        this.totalFare = totalFare;
        this.bookingId = bookingId;
        this.seatNo = seatNo;
        this.bookingDate = bookingDate;
    }
}
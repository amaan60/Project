import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { Booking } from './common/booking';
import { Bus } from './common/bus';
import {Http, Response, Headers,RequestOptions} from '@angular/http';
import { map, catchError} from 'rxjs/operators';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class BookingService 
{
 booking : Booking;
 bus : Bus;
 private  bookingbaseUrl = "http://localhost:8081/booking";
 private headers = new Headers({'Content-Type' : 'application/json'});
 private options  = new RequestOptions({headers: this.headers});

  constructor(private http : Http) { }
  getAllSourceStation()
  {
    return this.http.get(this.bookingbaseUrl+'/source').pipe(map((response : Response) => response.json())).pipe(catchError(this.errorHandler));
  }
  getAllDestinationStation()
  {
    return this.http.get(this.bookingbaseUrl+'/destination').pipe(map((response : Response) => response.json())).pipe(catchError(this.errorHandler));
  }
  searchBus(sourceStation,destinationStation)
  {
    return this.http.get(this.bookingbaseUrl+'/searchbus/'+sourceStation+"+"+destinationStation).pipe(map((response : Response) => response.json())).pipe(catchError(this.errorHandler));
  }
  addBooking(booking : Booking)
  {
    return this.http.post(this.bookingbaseUrl+'/new', JSON.stringify(booking) ,this.options).pipe(map((response : Response)=>response.json()));
  }
  getBookingById(id: number)
  {
    return this.http.get(this.bookingbaseUrl+'/bookingbyid/'+id).pipe(map((response : Response) => response.json())).pipe(catchError(this.errorHandler));;
  }
  deleteBooking(id: number)
  {
    return this.http.delete(this.bookingbaseUrl+'/delete/'+id).pipe(map((response : Response) => response.json()));
  }
  getAllBus()
  {
    return this.http.get(this.bookingbaseUrl+'/buses/').pipe(map((response : Response) => response.json())).pipe(catchError(this.errorHandler));
  }
  getBusById(id : number)
  {
    return this.http.get(this.bookingbaseUrl+'/busbyid/'+id).pipe(map((response : Response) => response.json())).pipe(catchError(this.errorHandler));
  }
  updateBus(bus : Bus)
  {
    return this.http.put(this.bookingbaseUrl+'/updatebus', JSON.stringify(bus) ,this.options).pipe(map((response : Response)=>response.json()));
  }
  errorHandler(error)
  {
    console.log(error);
    
       return throwError(error);       
  }
}

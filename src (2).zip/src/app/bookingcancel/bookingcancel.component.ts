import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { BookingService } from '../booking.service';
import { Bus } from '../common/bus';
import { Booking } from '../common/booking';
import { BusService } from '../bus.service';

@Component({
  selector: 'app-bookingcancel',
  templateUrl: './bookingcancel.component.html',
  styleUrls: ['./bookingcancel.component.css']
})
export class BookingcancelComponent implements OnInit {
  bus: Bus;
  errorBlock = false;
  errorText: string;
  bookingIdFlag = false;
  bookingCancelFlag = false;
  booking: Booking;
  cancellationform = new FormGroup({
    bookingId: new FormControl('',{
      validators: Validators.compose([
        Validators.required,
        Validators.pattern("^[0-9]{1,4}$")
      ])
    }),
    cancellationreason: new FormControl('')
  })
  constructor(private bookingservice: BookingService, private busservice: BusService) { }
  ngOnInit(): void {
  }
  cancelBooking() {
    console.log(this.bus);
    let bookingId = parseInt(this.cancellationform.get('bookingId').value);
    this.bookingservice.getBookingById(bookingId).subscribe((booking) => {
      this.errorBlock = false;
      this.booking = booking;
    },
      (error) => {
        this.errorBlock = true;
        this.bookingCancelFlag = false;
        this.errorText = error._body;
      }
    )
    console.log(this.booking);
    if (this.booking == null){
      this.bookingIdFlag = true;}
    else {
      this.bookingservice.getBusById(this.booking.busId).subscribe((bus) => {
        this.bus = bus;
      })
      this.bus.seatsBooked = this.bus.seatsBooked - this.booking.seatsBooked;
      this.bookingservice.updateBus(this.bus).subscribe((bus) => {
        console.log(bus);
      })
      this.bookingIdFlag = false;
      this.bookingCancelFlag = true;
      this.bookingservice.deleteBooking(bookingId).subscribe((data) => {
        console.log(data);
      })
    }
  }
}

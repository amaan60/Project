import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { Booking } from '../common/booking';
import { BookingService } from '../booking.service';
import { Bus } from '../common/bus';
import { Router, ActivatedRoute } from '@angular/router';
import { BookingDetails } from '../bookingdetails';
import { PassengerdataService } from '../passengerdata.service';
import { BusService } from '../bus.service';

@Component({
  selector: 'app-bookingpage',
  templateUrl: './bookingpage.component.html',
  styleUrls: ['./bookingpage.component.css']
})
export class BookingpageComponent implements OnInit {
  pass2flag = true;
  pass3flag = true;
  pass4flag = true;
  selectedBusId :any;
  bus:Bus[];
  bookingConfirmFlag = false;
  passengerNames = [];
  passengerAges = [];
  busById: Bus;
  bookingId: number;
  totalSeatsBooked: number;
  bookingDetails: BookingDetails;
  bookingform = new FormGroup({
    busId: new FormControl(
      {
        
      }),
    numberOfPassengers: new FormControl('',
      {
        validators: Validators.required
      }),
    passengerName1: new FormControl('', {
      validators: Validators.compose([
        Validators.required,
        Validators.pattern("([a-zA-Z]+( [a-zA-Z]+)*){2,30}")
      ])
    }),
    passengerName2: new FormControl('',
      {
        validators: Validators.compose([
          Validators.required,
          Validators.pattern("([a-zA-Z]+( [a-zA-Z]+)*){2,30}")
        ])

      }),
    passengerName3: new FormControl('',
      {
        validators: Validators.compose([
          Validators.required,
          Validators.pattern("([a-zA-Z]+( [a-zA-Z]+)*){2,30}")
        ])
      }),
    passengerName4: new FormControl('', {
      validators: Validators.compose([
        Validators.required,
        Validators.pattern("([a-zA-Z]+( [a-zA-Z]+)*){2,30}")
      ])
    }
    ),
    passengerAge1: new FormControl('',
      {
        validators: Validators.compose([
          Validators.required,
          Validators.pattern("(?:|-)([1-9]{1,2}[0]?|100)")
        ])
      }),
    passengerAge2: new FormControl('',
      {
        validators: Validators.compose([
          Validators.required,
          Validators.pattern("(?:|-)([1-9]{1,2}[0]?|100)")
        ])
      }),
    passengerAge3: new FormControl('',
      {
        validators: Validators.compose([
          Validators.required,
          Validators.pattern("(?:|-)([1-9]{1,2}[0]?|100)")
        ])
      }),
    passengerAge4: new FormControl('',
      {
        validators: Validators.compose([
          Validators.required,
          Validators.pattern("(?:|-)([1-9]{1,2}[0]?|100)")
        ])
      }),
    phoneNumber: new FormControl('',
      {
        validators: Validators.compose([
          Validators.required,
          Validators.pattern("[7-9][0-9]{9}")
        ])
      })
  })

  constructor(private router: Router, private passengerdataservice: PassengerdataService,private bookingservice : BookingService, private route:ActivatedRoute) {
  }
  ngOnInit(): void {
    this.onChanges();
    this.bookingservice.getAllBus().subscribe((bus) => {
      this.bus = bus;
    })
     this.selectedBusId = this.route.snapshot.paramMap.get('busid');
     if(this.selectedBusId==null){
              this.selectedBusId=0;
     }
       console.log(this.selectedBusId);
       
  }
  passengersCount() {
    let numberOfPassengers = parseInt(this.bookingform.get('numberOfPassengers').value);
  }
  onChanges() {
    this.bookingform.get('numberOfPassengers').valueChanges
      .subscribe(selectedPassengers => {
        if (selectedPassengers == 1) {

          this.bookingform.get('passengerName2').disable();
          this.bookingform.get('passengerName3').disable();
          this.bookingform.get('passengerName4').disable();
          this.bookingform.get('passengerAge2').disable();
          this.bookingform.get('passengerAge3').disable();
          this.bookingform.get('passengerAge4').disable();
        }
        else if (selectedPassengers == 2) {

          this.bookingform.get('passengerName3').disable();
          this.bookingform.get('passengerName4').disable();
          this.bookingform.get('passengerAge3').disable();
          this.bookingform.get('passengerAge4').disable();
        }
        else if (selectedPassengers == 3) {
          this.bookingform.get('passengerName4').reset();
          this.bookingform.get('passengerName4').disable();
          this.bookingform.get('passengerAge4').reset();
          this.bookingform.get('passengerAge4').disable();
        }
      });
  }
  savePaymentDetails() {
    let busId = this.bookingform.get('busId').value;
    console.log(busId);
    if(this.selectedBusId!=0){
      busId = parseInt(this.selectedBusId);
    }
    this.bookingservice.getBusById(busId).subscribe((bus) => {
      this.busById = bus;
      console.log(this.busById);
    })
    this.totalSeatsBooked = this.busById.seatsBooked;
    let busFare;
    let seatNo1 = "", seatNo2 = "", seatNo3 = "", seatNo4 = "";
    let numberOfPassengers = parseInt(this.bookingform.get('numberOfPassengers').value);
    let passengerName1 = this.bookingform.get('passengerName1').value;
    let passengerAge1 = this.bookingform.get('passengerAge1').value;
    let passengerName2 = this.bookingform.get('passengerName2').value;
    let passengerAge2 = this.bookingform.get('passengerAge2').value;
    let passengerName3 = this.bookingform.get('passengerName3').value;
    let passengerAge3 = this.bookingform.get('passengerAge3').value;
    let passengerName4 = this.bookingform.get('passengerName4').value;
    let passengerAge4 = this.bookingform.get('passengerAge4').value;
    if (passengerName1 != '') {
      this.passengerNames.push(passengerName1);
      this.passengerAges.push(passengerAge1);
      seatNo1 = this.totalSeatsBooked++ + "A";
    }
    if (passengerName2 != '') {
      this.passengerNames.push(passengerName2);
      this.passengerAges.push(passengerAge2);
      seatNo2 = this.totalSeatsBooked++ + "B";
    }
    if (passengerName3 != '') {
      this.passengerNames.push(passengerName3);
      this.passengerAges.push(passengerAge3);
      seatNo3 = this.totalSeatsBooked++ + "A";
    }
    if (passengerName4 != '') {
      this.passengerNames.push(passengerName4);
      this.passengerAges.push(passengerAge4);
      seatNo4 = this.totalSeatsBooked++ + "B";
    }
    let phoneNumber = this.bookingform.get('phoneNumber').value;
     busFare = this.busById.fare * numberOfPassengers;
    let passengerNamesStr = "";
    let seatNoStr = "";
    for (var i = 0; i < this.passengerNames.length; i++) 
    {
      if(passengerNamesStr==""){
        passengerNamesStr = this.passengerNames[i];
      }
      else{
      passengerNamesStr = passengerNamesStr + "," + this.passengerNames[i];
      }
    }
    seatNoStr = seatNo1 + " "+seatNo2 + " "+seatNo3+" "+seatNo4;
    
    let bookingdetailsobj = new BookingDetails(busId, passengerNamesStr, numberOfPassengers, busFare, 230, seatNoStr, this.busById.sourceStation, this.busById.destinationStation, this.busById.boardingTime, this.busById.dropTime, this.busById.busType);
    this.passengerdataservice.storePassengerData(bookingdetailsobj);
    this.router.navigate(['/paymentpage']);
  }
}

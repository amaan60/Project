import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PassengerdataService } from '../passengerdata.service';
import { BookingDetails } from '../bookingdetails';
import { ThrowStmt } from '@angular/compiler';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { BookingService } from '../booking.service';
import { Bus } from '../common/bus';
import { Booking } from '../common/booking';
import { BusService } from '../bus.service';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {
  booking: BookingDetails[] = [];
  bus: Bus;
  bookingId: number;
  bookingConfirmFlag = false;
  passengerDetailsFlag = false;
  passengerNames: string[];
  constructor(private passengerdataservice: PassengerdataService, private bookingservice: BookingService, private busService : BusService) { }
  paymentsform = new FormGroup({
    cardNumber: new FormControl('',
    {
      validators: Validators.compose([
        Validators.required,
        Validators.pattern("^[0-9]{10,12}$")
      ])
    }),
    cardCvv: new FormControl('',
    {
      validators: Validators.compose([
        Validators.required,
        Validators.pattern("[0-9]{3}")
      ])
    })
  })
  ngOnInit(): void {
    this.loadPassengerData();
  }
  loadPassengerData() {
    this.passengerdataservice.passengerData$.subscribe(message => {
      this.booking.push(message);
      console.log(this.booking);
    });
  }
  bookSeats() {
    this.bookingservice.getBusById(this.booking[0].busId).subscribe((bus) => {
      this.bus = bus;
    });
     console.log(this.bus);
     
     let seatsBooked = (this.bus.seatsBooked) + this.booking[0].seatsBooked;
        let busupdate = new Bus(this.bus.busId, this.bus.sourceStation, this.bus.destinationStation, this.bus.boardingTime, this.bus.dropTime, this.bus.busType, this.bus.totalSeats, seatsBooked, this.bus.fare);
        this.bookingservice.updateBus(busupdate).subscribe((busupdate) => {
          console.log(busupdate);
        });
    let count = 0;
    this.passengerNames = this.booking[0].passengerNames.split(',');
    this.bookingId = Math.floor(Math.random() * 1000) + 1;  
    let booking = new Booking(this.booking[0].busId, this.passengerNames, this.booking[0].seatsBooked, this.booking[0].totalFare, this.bookingId, this.booking[0].seatNo, new Date().toISOString().toString().substring(0,10));
    this.bookingservice.addBooking(booking).subscribe((booking) => {
      console.log(booking);
      this.bookingConfirmFlag = true;
    })
  }
}

import { Component, OnInit } from '@angular/core';
import { BookingService } from '../booking.service';
import { Bus } from '../common/bus';
import { Router, ActivatedRoute } from '@angular/router';
import { BusService } from '../bus.service';
import { DatePipe } from '@angular/common'


@Component({
  selector: 'app-booking',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.css']
})
export class BookingComponent implements OnInit {

  errorBlock = false;
  errorText: any;
  searchResultFlag = false;
  searchList: Bus[] = [];
  bus: Bus[];
  sourceStation : string[] = [];
  destinationStation : string[] = [];
  journeyDate: string;
  searchFlag = true;
  formattedDate: string;
  constructor(private bookingservice : BookingService, public router: Router, public datePipe : DatePipe) { }
  ngOnInit(): void {
    this.listSourceStation();
    this.listDestinationStation();
    this.dateFormatter();
    console.log(this.formattedDate);
    
    
  }
  listSourceStation() {
    this.bookingservice.getAllSourceStation().subscribe((sourceStation) => {
      this.sourceStation = sourceStation;
    })
  }
  listDestinationStation() {
    this.bookingservice.getAllDestinationStation().subscribe((destinationStation) => {
      this.destinationStation = destinationStation;
    })
  }
  searchBus(source, destination, date) {
     if(source ==0 || destination ==0){
       alert("Please fill in details!")
     }
       this.bookingservice.searchBus(source, destination).subscribe((bus) => {
      this.bus = bus;
    },
      (error) => {
        this.errorBlock = true;
        this.errorText = error._body;
      }
    )
    for (let i = 0; i < this.bus.length; i++) {
        this.journeyDate = this.bus[i].boardingTime.toString().substring(0, 10);
        console.log(this.journeyDate);
        console.log(date);
        if (date == this.journeyDate) {
          this.searchList.push(this.bus[i]);
          this.searchResultFlag = false;
        }
    }
    if (this.searchList[0] == null) {
      this.searchResultFlag = true;
    }
  }
  bookSeats(busId) {
    this.searchFlag = false;
    this.router.navigate(['/bookingpage', busId]);
  }
  dateFormatter(){
    let date=new Date();
     this.formattedDate =this.datePipe.transform(date, 'yyyy-MM-dd');
   }
}
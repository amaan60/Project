import { UniquefilterPipe } from './uniquefilter.pipe';

describe('UniquefilterPipe', () => {
  it('create an instance', () => {
    const pipe = new UniquefilterPipe();
    expect(pipe).toBeTruthy();
  });
});

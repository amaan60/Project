import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { BookingService } from '../booking.service';
import { Booking } from '../common/booking';
import { Bus } from '../common/bus';
import { BookingDetails } from '../bookingdetails';
import { BusService } from '../bus.service';
import * as jspdf from 'jspdf';
import html2canvas from 'html2canvas';
@Component({
  selector: 'app-ticketgeneration',
  templateUrl: './ticketgeneration.component.html',
  styleUrls: ['./ticketgeneration.component.css']
})
export class TicketgenerationComponent implements OnInit {
  ticketdetailsflag = false;
  ticketgenerationflag = false;
  errorBlock = false;
  errorText: string;
  bookingIdFlag = false;
  bus: Bus;
  booking: Booking;
  bookingdetails: BookingDetails[] = [];
  ticketgenerationform = new FormGroup({
    bookingId: new FormControl('',
    {
      validators: Validators.compose([
        Validators.required,
        Validators.pattern("^[0-9]{1,4}$")
      ])
    })
  })
  constructor(private bookingservice: BookingService, private busservice: BusService) { }

  ngOnInit(): void {
  }

  generateTicket() {
    let bookingId = this.ticketgenerationform.get('bookingId').value;
    this.bookingservice.getBookingById(bookingId).subscribe((booking) => {
      this.errorBlock = false;
      this.booking = booking;
    }
      ,
      (error) => {
        this.errorBlock = true;
        this.errorText = error._body;
      }
    )
    this.bookingservice.getBusById(this.booking.busId).subscribe((bus) => {
      this.bus = bus;
    });
    console.log(this.booking);
    if (this.booking != null) {
      this.ticketgenerationflag = true;
      this.bookingIdFlag = false;
    }
    else {
      this.ticketgenerationflag = false;
      this.bookingIdFlag = true;
    }
  }
  showTicket() {
    let passengerNames: string = "";
    for (let i = 0; i < this.booking.seatsBooked; i++) {
      passengerNames = passengerNames + "," + this.booking.passengerNames[i];
    }
    this.ticketdetailsflag = true;
    let bookingdetailobj = new BookingDetails(this.booking.busId, passengerNames, this.booking.seatsBooked, this.booking.totalFare, this.booking.bookingId, this.booking.seatNo, this.bus.sourceStation, this.bus.destinationStation, this.bus.boardingTime, this.bus.dropTime, this.bus.busType);
    this.bookingdetails.push(bookingdetailobj);
    console.log(this.bookingdetails);
  } 
  printTicket(){
  // var data = document.getElementById("passengerTicket");
  html2canvas(document.body).then(canvas => {
    var imgWidth = 208;
    var pageHeight = 295;
    var imgHeight = canvas.height*imgWidth /canvas.width;
    var heightLeft = imgHeight;
    const contentDataUrl = canvas.toDataURL('image/png')
    let pdf = new jspdf('p', 'mm', 'a4'); //A4 size for pdf
    var position = 0;
    pdf.addImage(contentDataUrl, 'PNG',0,position,imgWidth,imgHeight);
    pdf.save('Ticket.pdf'); //Generated pdf
  });
  }
}

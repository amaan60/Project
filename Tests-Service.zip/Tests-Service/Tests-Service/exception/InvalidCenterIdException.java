package com.cg.healthcaresystem.centers.exception;

public class InvalidCenterIdException extends RuntimeException {

	public InvalidCenterIdException(String arg0) {
		super(arg0);
	}
	

	
}




insert into test values('5682HJSP',  '235345DFDAF','Blood Test'); 
insert into test values('3412HJSP', '235345DFDAF','MRI');
insert into test values('9022HJSP','235345DFDAF' ,'X-Ray'); 
insert into test values('3342ADSP', '34645AKAFD','MRI');
insert into test values('322HJSP','2d45DFLDAF' ,'Swab Test'); 
 



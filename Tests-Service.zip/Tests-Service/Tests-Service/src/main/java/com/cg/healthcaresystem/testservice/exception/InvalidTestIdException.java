package com.cg.healthcaresystem.testservice.exception;

public class InvalidTestIdException extends RuntimeException {

	public InvalidTestIdException(String arg0) {
		super(arg0);
	}
	

	
}

package com.cg.healthcaresystem.testservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
